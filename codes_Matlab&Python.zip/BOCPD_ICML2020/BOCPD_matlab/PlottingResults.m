function p = PlottingResults(environment, y1,y2, vectChangePoint, title1, title2, col1, col2)

font = 12;
%-------------------------  Plotting the environment  ---------------------


figure; 
subplot(2,1,1)
grid on;
Gr = [0 0.5 0];
grid on
plot(environment, 'color', Gr, 'linewidth',2)
xlim([1,length(environment)])
ylim([0,1])
labelsX = {'\fontsize{12}\color[rgb]{0 0.5 0}1','\fontsize{12}\color[rgb]{0 0.5 0}301',...
    '\fontsize{12}\color[rgb]{0 0.5 0}701','\fontsize{12}\color[rgb]{0 0.5 0}1051','1251'};
set(gca,'XTickLabels',labelsX)
set(gca,'XTick',[vectChangePoint length(environment)] );
set(gca,'YTick',[0 unique(environment) 1] );
xlabel('\textbf{Time step $$t$$}','Interpreter','latex');
ylabel('Expectations')
title('Piece-wise stationary Bernoulli distribution')
set(gca,'FontSize',font,'fontWeight','bold', 'fontName','georgia')
grid on 
%----------------------- Plotting figure 1 ------------------------------
subplot(2,1,2)
lineProps1.width = 2;
lineProps2.width = 2;


hold on 
col{1} = col1; lineProps1.col = col; y_mean1 = mean(y1,1); p = plot(y_mean1,'-','color',col1,'linewidth',3);
col{1} = col2; lineProps2.col = col; y_mean2 = mean(y2,1); plot(y_mean2,'color',col2,'linewidth',2); 

%scatter(vectChangePoint,vectChangePoint,'ko','filled','MarkerEdgeColor',[0 0.7 0.7],...
 %             'MarkerFaceColor',[0 0.5 0], 'LineWidth',1) %Optimal = Newly

grid on 

xlabel('\textbf{Time step $$t$$}','Interpreter','latex'); xlim([1,length(y_mean1)])
title('\textbf{Change-point estimation $$\hat{\tau}_t$$}','Interpreter','latex')

labelsX = {'\fontsize{14}\color[rgb]{0 0.5 0}1','\fontsize{14}\color[rgb]{0 0.5 0}301',...
    '\fontsize{14}\color[rgb]{0 0.5 0}701','\fontsize{14}\color[rgb]{0 0.5 0}1051','1251'};

labelsY = {'\fontsize{14}\color[rgb]{0 0.5 0}1','\fontsize{14}\color[rgb]{0 0.5 0}301',...
    '\fontsize{14}\color[rgb]{0 0.5 0}701','\fontsize{14}\color[rgb]{0 0.5 0}1051'};

set(gca,'XTickLabels',labelsX)
set(gca,'YTickLabels',labelsY )
set(gca,'XTick',[vectChangePoint length(y_mean1)] ); set(gca,'YTick',vectChangePoint );
set(gca,'FontSize',font,'fontWeight','bold', 'fontName','georgia')
lgd = legend(title1,title2);

y_std1 = std(y1,[],1); mseb([],y_mean1, y_std1, lineProps1, 1.5)
y_std2 = std(y2,[],1); mseb([],y_mean2, y_std2, lineProps2, 1.5)
ylim([0,max(max([y1 y2]))])
lgd.Location = 'northwest';


%{
%-------------- PLotting figure 2 ---------------------------------------

subplot(2,1,3)
lineProps3.width = 2;


hold on 
col{1} = col3; lineProps3.col = col; y_mean3 = mean(y3,1); p = plot(y_mean3,'-','color',col3,'linewidth',3);
plot(y_mean2,'color',col2,'linewidth',2); 

%scatter(vectChangePoint,vectChangePoint,'ko','filled','MarkerEdgeColor',[0 0.7 0.7],...
 %             'MarkerFaceColor',[0 0.5 0], 'LineWidth',1) %Optimal = Newly

grid on 

xlabel('\textbf{Time step $$t$$}','Interpreter','latex'); xlim([1,length(y_mean1)])
title('\textbf{Change-point estimation $$\hat{\tau}_t$$}','Interpreter','latex')

labelsX = {'\fontsize{14}\color[rgb]{0 0.5 0}1','\fontsize{14}\color[rgb]{0 0.5 0}301',...
    '\fontsize{14}\color[rgb]{0 0.5 0}701','\fontsize{14}\color[rgb]{0 0.5 0}1051','1251'};

labelsY = {'\fontsize{14}\color[rgb]{0 0.5 0}1','\fontsize{14}\color[rgb]{0 0.5 0}301',...
    '\fontsize{14}\color[rgb]{0 0.5 0}701','\fontsize{14}\color[rgb]{0 0.5 0}1051'};

set(gca,'XTickLabels',labelsX)
set(gca,'YTickLabels',labelsY )
set(gca,'XTick',[vectChangePoint length(y_mean3)]); set(gca,'YTick',vectChangePoint );
set(gca,'FontSize',font,'fontWeight','bold', 'fontName','georgia')
lgd = legend(title3,title2);

y_std3 = std(y3,[],1); mseb([],y_mean3, y_std3, lineProps3, 1.5)
y_std2 = std(y2,[],1); mseb([],y_mean2, y_std2, lineProps2, 1.5)
ylim([0,max(max([y3 y2]))])
lgd.Location = 'northwest';
%}








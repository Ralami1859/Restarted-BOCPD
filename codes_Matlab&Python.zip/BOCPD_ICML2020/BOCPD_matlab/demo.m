%% Demonstration of the Bayesian Online Change-point Detector

% environment -> Piece-wise stationary Bernoulli Distributions


%% Define the environment

vectChangePoint = [1 301 701 701+350]; % Change-point position (for plotting purposes)

BernoulliEnvironment = [0.8*ones(1,300)... 
               0.4*ones(1,400)...
               0.9*ones(1,350)...
               0.5*ones(1,200)]; % Piecewise stationary Bernoulli Distributions
           
NbrRuns= 300; % Nbr Runs
%% Restarted Bayesian Online Change-point detector

[CP_Modified_restart]= Restarted_BOCPD(BernoulliEnvironment, NbrRuns); 

%% Original Bayesian Online Change-point detector 

[CP_Original]= BOCPD(BernoulliEnvironment, NbrRuns); % Original version (Adams 2007)

%% Plotting the results

close all
col1 = [1 0 0];
col2 = [0 0 1];

p = PlottingResults(BernoulliEnvironment,CP_Modified_restart, CP_Original, vectChangePoint, 'R-BOCPD','BOCPD',col1, col2); % Plotting results for restart version of BOCD and BOCDm

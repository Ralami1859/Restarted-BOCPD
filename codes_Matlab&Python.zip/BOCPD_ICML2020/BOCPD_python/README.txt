This folder contains:

 --- the python codes of the algorithms BOCPD and Restarted_BOCPD
 

============================ Python codes =======================================

 -1- BOCD_Algorithms.py contains the two versions of the Bayesian Online Change-point Detection
 -2- demoOnlineDetection.py is a demonstration of the two algorithms (BOCPD, Restarted_BOCPD)
	in a piece-wise Bernoulli environment
	
----> For a demon please launch the following script: demoOnlineDetection.py

